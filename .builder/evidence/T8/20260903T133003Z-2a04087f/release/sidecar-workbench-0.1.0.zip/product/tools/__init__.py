"""Installed deterministic tool catalog."""
