"""Bounded target text reader."""
