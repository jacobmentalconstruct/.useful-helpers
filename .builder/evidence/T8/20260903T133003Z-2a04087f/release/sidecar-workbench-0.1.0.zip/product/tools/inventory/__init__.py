"""Target resource inventory tool."""
